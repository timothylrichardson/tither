package org.mt_pilgrim.tither;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TitherAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
