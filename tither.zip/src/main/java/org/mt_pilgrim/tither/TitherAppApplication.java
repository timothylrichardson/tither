package org.mt_pilgrim.tither;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TitherAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TitherAppApplication.class, args);
	}

}
